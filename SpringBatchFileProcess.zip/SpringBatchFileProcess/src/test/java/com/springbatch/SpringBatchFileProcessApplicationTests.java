package com.springbatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBatchFileProcessApplicationTests {

	@Test
	void contextLoads() {
	}

}
