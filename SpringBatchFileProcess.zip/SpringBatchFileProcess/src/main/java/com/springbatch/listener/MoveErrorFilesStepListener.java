package com.springbatch.listener;

import java.io.File;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.file.ResourceAwareItemReaderItemStream;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import com.springbatch.entity.Customer;



@Component
public class MoveErrorFilesStepListener implements StepExecutionListener, Tasklet {
	
	
	@Value("${files.error.path}")
	private String errorPath;
	
	private ResourceAwareItemReaderItemStream<Customer> itemReader;
	
	@Override
    public void beforeStep(StepExecution stepExecution) {
        // Do nothing before step
    }
	
	
	@Override
    public ExitStatus afterStep(StepExecution stepExecution) {
		if (stepExecution.getExitStatus().equals(ExitStatus.UNKNOWN)) {
            // Get the file path for the last read item
			String errorFilePath = ((FileSystemResource) ((Object) itemReader)).getPath();
			
          // Create the error file folder if it does not exist
			new File(errorPath).mkdirs();
			
			
          // Move the error file to the error file folder
			File errorFile = new File(errorFilePath);
			
			errorFile.renameTo(new File(errorPath + File.separator + errorFile.getName()));
            
            
		}
        return stepExecution.getExitStatus();
    }

	
	
	 public void setErrorFolderPath(String errorPath) {
	        this.errorPath = errorPath;
	    }
	 public void setItemReader(ResourceAwareItemReaderItemStream<Customer> itemReader) {
	        this.itemReader = itemReader;
	    }


	public void setResourcesPath(String errorPath2) {
		
		
	}


	public void setResources(Resource[] resources) {
	
		
	}


	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		return null;
	}
	}