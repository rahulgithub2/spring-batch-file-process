package com.springbatch.processor;

import java.time.LocalDateTime;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.springbatch.entity.Customer;

@Component
public class CustomerItemProcessor implements ItemProcessor<Customer, Customer> {

	@Value("${files.path}")
	private String resourcesPathsString;

	@Value("${files.type}")
	private String fileType;



	String filename;
	
	
	public CustomerItemProcessor(String filename) {
		System.out.println(filename+" Hello File name");
		this.filename=filename;
	}
	
	public CustomerItemProcessor() {}
	
	@Override
	public Customer process(final Customer customer) throws Exception {
		final String Sno = customer.getSno();
		final String ActionCode = customer.getActionCode().toUpperCase();
		final String ExistingMerchant = customer.getExistingMerchant().toUpperCase();
		final String CustomerNo = customer.getCustomerNo().toUpperCase();
		final String MID = customer.getMID().toUpperCase();

		LocalDateTime now = LocalDateTime.now();
		customer.setDateTime1(now);

		final Customer transformedPerson = new Customer(Sno, ActionCode, ExistingMerchant, CustomerNo, MID, filename,
				now);

		return transformedPerson;
	}

}
