package com.springbatch.configuration;


import java.util.Collection;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;


import org.springframework.batch.core.ExitStatus;


public class MoveFilesTasklet implements Tasklet{
	
	private String resourcesPath;

	public String getResourcesPath() {
		return resourcesPath;
	}

	public void setResourcesPath(String resourcesPath) {
		this.resourcesPath = resourcesPath;
	}
	
	private Resource[] resources;

	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {
		
		Collection<StepExecution> stepExecutions = chunkContext.getStepContext().getStepExecution().getJobExecution()
				.getStepExecutions();
		
		for (StepExecution stepExecution : stepExecutions) {
			if (stepExecution.getExecutionContext().containsKey("fileName")
					&& ExitStatus.COMPLETED.equals(stepExecution.getExitStatus())
					&& stepExecution.getFailureExceptions().size() <= 0) {
				String file = stepExecution.getExecutionContext().getString("fileName");
				System.out.println("In execute method file " +file );
				String path = file.replace("file:/", "");
				System.out.println("In execute method path " +path );
				String[] filename = file.split("/");
				
				for (int i = 0; i < filename.length; i++) {
					System.out.println("filename   ::  "+ filename[i]);
				}
				try {
					System.out.println("In execute method filename " +filename );
					System.out.println("In execute method filename array " +filename[3]);
				} catch (Exception e) {
					System.out.println(e);
				}
				
				
				org.apache.commons.io.FileUtils.moveFile(org.apache.commons.io.FileUtils.getFile(path),
						org.apache.commons.io.FileUtils.getFile(resourcesPath+filename[3]));
		
			}}
		return RepeatStatus.FINISHED;
	}
	public void setResources(Resource[] resources) {
		this.resources = resources;
	}

	public void afterPropertiesSet() throws Exception {
		Assert.notNull(resources, "directory must be set");
	}
}
