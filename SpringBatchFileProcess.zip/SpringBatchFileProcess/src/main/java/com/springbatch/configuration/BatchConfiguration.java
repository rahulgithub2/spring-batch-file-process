package com.springbatch.configuration;

import java.io.IOException;
import java.net.MalformedURLException;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.partition.support.MultiResourcePartitioner;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.io.UrlResource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.springbatch.entity.Customer;
import com.springbatch.listener.CustomerStepListener;
import com.springbatch.processor.CustomerItemProcessor;
import com.springbatch.tasklet.MoveErrorFilesTasklet;



@Configuration
@EnableBatchProcessing
@EnableScheduling
public class BatchConfiguration {

	@Autowired
	DataSource dataSource;
	
	@Autowired
	public JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	public StepBuilderFactory stepBuilderFactory;
	
	
	
	@Autowired
	private FlatFileItemReader<Customer> customerItemReader;
	
	@Autowired
	private JdbcBatchItemWriter<Customer> customerItemWriter;
	
	@Autowired
	private CustomerItemProcessor customerItemProcessor;
	
	@Value("${files.path}")
	private String resourcesPath;
	
	@Value("${files.error.path}")
	private String errorPath;
	
	@Value("${files.success.path}")
	private String sucessPath;
	
	@Value("${files.type}")
	private String fileType;
	
	

	@Bean
	@JobScope
	public Partitioner partitioner() throws Exception {
		MultiResourcePartitioner partitioner = new MultiResourcePartitioner();
		PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
		partitioner.setResources(resolver.getResources("file:" + resourcesPath  + fileType));
		partitioner.partition(1);
		return partitioner;
	}
	
	@Bean
	@StepScope
	@Qualifier("customItemProcessor")
	public CustomerItemProcessor processor() throws Exception{
		return new CustomerItemProcessor();
	}

	@Bean
	@StepScope
	@Qualifier("customerItemWriter")
	public JdbcBatchItemWriter<Customer> writer(DataSource dataSource) throws Exception{
		return new JdbcBatchItemWriterBuilder<Customer>()
				.itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
				.sql("insert into customers(Sno,action_code,existing_merchant,customer_no,mid,date_time,filename) values(:Sno,:ActionCode,:ExistingMerchant,:CustomerNo,:MID,:dateTime,:filename)")
				.dataSource(dataSource)
				.build();
	}
	
	@Bean
	public Job importUserJob() throws Exception {
		return jobBuilderFactory.get("importUserJob")
				.incrementer(new RunIdIncrementer())
				.listener(new CustomerStepListener())
				.start(masterStep()).on("COMPLETED").to(moveFiles())
				.from(masterStep()).on("UNKONWN").to(moveErrorFiles()).end().build();
    }
	
	
	
	
	  private Step moveErrorFiles() {
		  MoveErrorFilesTasklet moveFilesTasklet1= new  MoveErrorFilesTasklet();
		  try { 
			  moveFilesTasklet1.setResourcesPath(errorPath);
	          moveFilesTasklet1.setResources(new PathMatchingResourcePatternResolver().getResources("file:" + errorPath +  fileType));
	          } catch (IOException e) {
	  
	             } return  stepBuilderFactory.get("moveErrorFiles").tasklet(moveFilesTasklet1).build();
	  }
	  
	 
	@Bean
	public Step step1() throws Exception{
		return stepBuilderFactory.get("step1")
				.<Customer, Customer>chunk(10)
				.reader(customerItemReader)
				.processor(customerItemProcessor)
				.writer(writer(dataSource))
				.build();
	}
	
	@Bean
	public ThreadPoolTaskExecutor taskExecutor() {
		ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
		taskExecutor.setMaxPoolSize(10);
		taskExecutor.setCorePoolSize(10);
		taskExecutor.setQueueCapacity(10);
		taskExecutor.afterPropertiesSet();
		return taskExecutor;
	}
	
	@Bean
	@Qualifier("masterStep")
	public Step masterStep() throws Exception{
		return stepBuilderFactory.get("masterStep").partitioner(step1())
				.partitioner("step1", partitioner())
				.step(step1())
				.taskExecutor(taskExecutor())
			//	.listener(new CustomerStepListener())
				.build();
	}
	
	@Bean
	protected Step moveFiles()throws Exception {
		MoveFilesTasklet moveFilesTasklet = new MoveFilesTasklet();
		try {
			System.out.println("sucessPath from moveFiles :::: "+ sucessPath);
			moveFilesTasklet.setResourcesPath(sucessPath);
			moveFilesTasklet.setResources(new PathMatchingResourcePatternResolver().getResources("file:" + sucessPath + fileType));
		} catch (IOException e) {
			
		}
		return stepBuilderFactory.get("moveFiles").tasklet(moveFilesTasklet).build();
	}
	 
	@Bean
	@StepScope
	@Qualifier("customerItemReader")
	@DependsOn("partitioner")
	public FlatFileItemReader<Customer> customerItemReader(@Value("#{stepExecutionContext['fileName']}") String filename)
			throws MalformedURLException {
	
		
		return new FlatFileItemReaderBuilder<Customer>().name("customerItemReader").linesToSkip(1)
				.delimited()
				.names( new String[] { "Sno", "ActionCode","ExistingMerchant","CustomerNo","MID"})
				.fieldSetMapper(new BeanWrapperFieldSetMapper<Customer>() {
					{
						setTargetType(Customer.class);	
					}
				})
				.resource(new UrlResource(filename))
				
				.build();
	}
	
	
	
}
