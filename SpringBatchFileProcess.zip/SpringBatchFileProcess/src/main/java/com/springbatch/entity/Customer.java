package com.springbatch.entity;

import java.io.Serializable;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="customers")
@Entity
public class Customer implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String Sno;
	private String ActionCode;
	private String ExistingMerchant;
	private String CustomerNo;
	private String MID;
	
	

	@Column(name = "filename")
	private String filename;

	public LocalDateTime dateTime;
	
	public Customer() {
		super();
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSno() {
		return Sno;
	}

	public void setSno(String sno) {
		Sno = sno;
	}

	public String getActionCode() {
		return ActionCode;
	}

	public void setActionCode(String actionCode) {
		ActionCode = actionCode;
	}

	public String getExistingMerchant() {
		return ExistingMerchant;
	}

	public Customer(String sno, String actionCode, String existingMerchant, String customerNo, String mID,
			String filename, LocalDateTime dateTime) {
		Sno = sno;
		ActionCode = actionCode;
		ExistingMerchant = existingMerchant;
		CustomerNo = customerNo;
		MID = mID;
		this.filename = filename;
		this.dateTime = dateTime;
	}

	

	public void setExistingMerchant(String existingMerchant) {
		ExistingMerchant = existingMerchant;
	}

	public String getCustomerNo() {
		return CustomerNo;
	}

	public void setCustomerNo(String customerNo) {
		CustomerNo = customerNo;
	}

	public String getMID() {
		return MID;
	}

	public void setMID(String mID) {
		MID = mID;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public LocalDateTime getDateTime() {
		return dateTime;
	}

	public void setDateTime1(LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", Sno=" + Sno + ", ActionCode=" + ActionCode + ", ExistingMerchant="
				+ ExistingMerchant + ", CustomerNo=" + CustomerNo + ", MID=" + MID + ", filename=" + filename
				+ ", dateTime=" + dateTime + "]";
	}

	public void setDateTime(LocalDateTime now) {
		// TODO Auto-generated method stub
		
	}
	
	


}
